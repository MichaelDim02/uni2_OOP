/*
 * Ονοματεπώνυμο: Δημόπουλος Μιχαήλ Κωνσταντίνος
 * ΑΜ: 2020038
 * Τμήμα: Τ26
 */

/*
 * @author michael
 */

public class Tachymetro {
    public void showTachymetro() {
        System.out.println("Tachymetro");
    }
}
